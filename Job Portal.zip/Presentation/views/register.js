const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const bcrypt = require('bcrypt');

const app = express();
const port = 3200;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',           // Replace with your MySQL username
    password: 'Asdf@123',   // Replace with your MySQL password
    database: 'job_portal', // Replace with your database name
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Routes
// Registration Page
app.get('/register', (req, res) => {
    res.render('register'); // Renders the registration form
});

// Registration POST Route
app.post('/register', (req, res) => {
    const { role } = req.body;

    if (role === 'job_seeker') {
        const { full_name, mobile, email, password, confirm_password } = req.body;

        // Check if passwords match
        if (password !== confirm_password) {
            return res.send('Passwords do not match');
        }

        // Hash the password
        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) throw err;

            // Insert into job_seekers table
            const query = 'INSERT INTO job_seekers (full_name, mobile, email, password) VALUES (?, ?, ?, ?)';
            db.query(query, [full_name, mobile, email, hashedPassword], (err, result) => {
                if (err) {
                    if (err.code === 'ER_DUP_ENTRY') {
                        return res.send('Email is already registered');
                    }
                    throw err;
                }
                res.send('Job Seeker Registration successful');
            });
        });

    } else if (role === 'employer') {
        const { company_name, company_email, contact, location, password, confirm_password } = req.body;

        // Check if passwords match
        if (password !== confirm_password) {
            return res.send('Passwords do not match');
        }

        // Hash the password
        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) throw err;

            // Insert into employers table
            const query = 'INSERT INTO employers (company_name, company_email, contact, location, password) VALUES (?, ?, ?, ?, ?)';
            db.query(query, [company_name, company_email, contact, location, hashedPassword], (err, result) => {
                if (err) {
                    if (err.code === 'ER_DUP_ENTRY') {
                        return res.send('Email is already registered');
                    }
                    throw err;
                }
                res.send('Employer Registration successful');
            });
        });

    } else {
        res.send('Invalid role selected');
    }
});

// Start Server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
