const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const bcrypt = require('bcrypt');

const app = express();
const port = 3200;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Replace with your MySQL username
    password: 'Asdf@123', // Replace with your MySQL password
    database: 'job_portal',
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Routes
// Home Page
app.get('/', (req, res) => {
    res.render('index', { title: 'SKR Job Portal' });
});

// Login Page
app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { role, email, password } = req.body;

    let query = '';
    if (role === 'job_seeker') {
        query = 'SELECT * FROM job_seekers WHERE email = ?';
    } else if (role === 'employer') {
        query = 'SELECT * FROM employers WHERE company_email = ?';
    }

    db.query(query, [email], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            const user = results[0];
            bcrypt.compare(password, user.password, (err, isMatch) => {
                if (isMatch) {
                    res.send(`Welcome, ${role === 'job_seeker' ? user.full_name : user.company_name}!`);
                } else {
                    res.send('Invalid email or password');
                }
            });
        } else {
            res.send('User not found');
        }
    });
});

// Registration Page
app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', (req, res) => {
    const { role } = req.body;

    if (role === 'job_seeker') {
        const { full_name, mobile, email, password, confirm_password } = req.body;

        if (password !== confirm_password) {
            return res.send('Passwords do not match');
        }

        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) throw err;

            const query = 'INSERT INTO job_seekers (full_name, mobile, email, password) VALUES (?, ?, ?, ?)';
            db.query(query, [full_name, mobile, email, hashedPassword], (err, results) => {
                if (err) {
                    if (err.code === 'ER_DUP_ENTRY') {
                        return res.send('Email is already registered');
                    }
                    throw err;
                }
                res.send('Job Seeker Registration successful');
            });
        });
    } else if (role === 'employer') {
        const { company_name, company_email, contact, location, password, confirm_password } = req.body;

        if (password !== confirm_password) {
            return res.send('Passwords do not match');
        }

        bcrypt.hash(password, 10, (err, hashedPassword) => {
            if (err) throw err;

            const query = 'INSERT INTO employers (company_name, company_email, contact, location, password) VALUES (?, ?, ?, ?, ?)';
            db.query(query, [company_name, company_email, contact, location, hashedPassword], (err, results) => {
                if (err) {
                    if (err.code === 'ER_DUP_ENTRY') {
                        return res.send('Email is already registered');
                    }
                    throw err;
                }
                res.send('Employer Registration successful');
            });
        });
    } else {
        res.send('Invalid role selection');
    }
});

// Start Server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
